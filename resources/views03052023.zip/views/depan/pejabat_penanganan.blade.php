<html lang="en">
<!-- <![endif]-->
<!-- head -->
<head>
<title>Website Resmi Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu Kabupaten Situbondo </title>
@include('depan.bagian.css_favicon')
<!-- custom css -->
<!-- end theme style -->
</head>
<!-- end head -->
<!--body start-->
<body>
<!-- preloader --> 
@include('depan.bagian.header')
<!-- end preloader --> 
<!--  top bar -->
  
 <div id="page-banner" class="page-banner-main" style="background-image: url('../gambar/frontend/dpmptsp-header-1.jpg')">
    <div class="container">
      <div class="page-banner-block">
        <div class="section">
          <h3 class="section-heading">Pejabat Penanganan Pengaduan</h3>
        </div>
        <ol class="breadcrumb">
          <li><a href="{{url('/')}}" style="font-weight: bold;">HOME</a></li>
          <li class="active"><a>Pejabat Penanganan Pengaduan</a></li>
        </ol>
      </div>
    </div>
  </div>
<!--  end page banner  -->
<!-- blog right -->    
  <div id="blog-right" class="blog-page blog-left-main-block blog-right-main-block">
    <div class="container">
      <div class="row">        
        <div class="col-sm-9">
        	
          <div class="news-block">
            <div class="news-img">
                  
            </div>
			<div class="news-dtl">
        <center>
        	
               <h3>&nbsp;</h3>
        <h4 style="font-size: 17pt; text-decoration: underline;">PENANGGUNGJAWAB PENANGANAN PENGADUAN DPMPTSP SITUBONDO</h4>
        <h5 style="color: #3A3A3A;">SEKRETARIS DAERAH KABUPATEN SITUBONDO</h5	>
        <p>&nbsp;</p>

        <h4 style="font-size: 17pt; text-decoration: underline;">KETUA PENANGANAN PENGADUAN DPMPTSP SITUBONDO</h4>
        <h5 style="color: #3A3A3A;">KEPALA DINAS PENANAMAN MODAL dan PELAYANAN TERPADU SATU PINTU</h5>

        <p>&nbsp;</p>

        </center>
        <p>&nbsp;</p>
        <h4>PEJABAT PENANGANAN PENGADUAN DPMPTSP SITUBONDO</h4>
        <p>&nbsp;</p>
        <table style="width: 300px;">
        <tbody>
        <tr style="height: 26px;">
        <td style="width: 185px; height: 26px;"><strong>NAMA</strong></td>
        <td style="width: 109px; height: 26px;"><strong>:</strong></td>
        <td style="width: 173px; height: 26px;"><strong>SITI SANIYAH, S.Sos</strong></td>
        </tr>
        <tr style="height: 26px;">
        <td style="width: 185px; height: 26px;"><strong>NIP</strong></td>
        <td style="width: 109px; height: 23px;"><strong>:</strong></td>
        <td style="width: 173px; height: 23px;"><strong>19660505 199003 2 013</strong></td>
        </tr>
        <tr style="height: 26px;">
        <td style="width: 185px; height: 26px;"><strong>TELP.</strong></td>
        <td style="width: 109px; height: 27.5938px;"><strong>:</strong></td>
        <td style="width: 173px; height: 27.5938px;"><strong> (0338) 672155</strong></td>
        </tr>
        <tr style="height: 26px;">
        <td style="width: 185px; height: 26px;"><strong>E-MAIL</strong></td>
        <td style="width: 109px; height: 36px;"><strong>:</strong></td>
        <td style="width: 173px; height: 36px;"><strong>SITINYANYA55@GMAIL.COM</strong></td>
        </tr>
        </tbody>
        </table>
        <p>&nbsp;</p>
        <h3>&nbsp;</h3>
        <h4>PETUGAS PENERIMA PENGADUAN DPMPTSP SITUBONDO</h4>
        <p>&nbsp;</p>
        <table style="width: 390px;">
        <tbody>
        <tr style="height: 26px;">
        <td style="width: 185px; height: 26px;"><strong>NAMA</strong></td>
        <td style="width: 109px; height: 26px;"><strong>:</strong></td>
        <td style="width: 490px; height: 26px;"><strong>ADELLA LAGARETA ISWANTO, S.Ak </strong></td>
        </tr>
        <tr style="height: 26px;">
        <td style="width: 185px; height: 26px;"><strong>NIP</strong></td>
        <td style="width: 109px; height: 23px;"><strong>:</strong></td>
        <td style="width: 490px; height: 23px;"><strong>-</strong></td>
        </tr>
        <tr style="height: 26px;">
        <td style="width: 185px; height: 26px;"><strong>TELP.</strong></td>
        <td style="width: 109px; height: 27.5938px;"><strong>:</strong></td>
        <td style="width: 490px; height: 27.5938px;"><strong> (0338) 672155</strong></td>
        </tr>
        <tr style="height: 26px;">
        <td style="width: 185px; height: 26px;"><strong>E-MAIL</strong></td>
        <td style="width: 109px; height: 36px;"><strong>:</strong></td>
        <td style="width: 490px; height: 36px;"><strong>ADELLALAGARETA8@GMAIL.COM</strong></td>
        </tr>
        </tbody>
        </table>
        <p>&nbsp;</p>
              
            </div>
          </div>    
        </div>
       			
          
                  
          
      
        <div class="col-sm-3">
          <div class="archives-widget">
            <h6>KATEGORI</h6>
            <div class="archives-content">
              <ul>
                <li><a href="{{ url('/berita')}}"><i class="fa fa-caret-right"></i>Berita</a></li>
                <li><a href="{{ url('/informasi')}}"><i class="fa fa-caret-right"></i>Informasi</a></li>
              </ul>
            </div>
          </div>           

          <div class="tab-widget">
            <h6>Berita Terbaru</h6>
     
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active">
              	@foreach($posts as $post)
                <div class="tab-widget-dtl">
                  <div class="tab-thumb">
                    <img src="{{asset($post->gambar)}}" class="img-responsive" alt="{{$post->judul}}">
                  </div>
                  <a href="{{url('/berita/'.$post->slug)}}">{{$post->judul}}</a>
                </div>                
                @endforeach
              </div>
             </div>
            </div>
            <div class="tab-widget">
            <h6>Informasi Terbaru</h6>
     
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active">
               @foreach($infos as $info)
                <div class="tab-widget-dtl">
                  <div class="tab-thumb">
                    <img src="{{asset($info->gambar)}}" class="img-responsive" alt="{{$info->judul}}">
                  </div>
                  <a href="{{url('/informasi/'.$info->slug)}}">{{$info->judul}}</a>
                </div>                
                @endforeach
              </div>
             </div>
            </div>


          <div class="tag-widget">
            <h6>DPMPTSP Tagline</h6>
            <div class="tags">
              <a href="#"><span class="badge">dpmptsp situbondo</span></a>
              <a href="#"><span class="badge">berita situbondo</span></a>
              <a href="#"><span class="badge">informasi situbondo</span></a>
              <a href="#"><span class="badge">website dpmptsp</span></a>
               <a href="#"><span class="badge">perizinan dpmptsp</span></a>
   
            </div>       
          </div>
        </div>
      </div>
    </div>
  </div>


<!--  end latest news -->
<!--  clients -->
@include('depan.bagian.footer')
<!--  end map -->
<!--  footer -->

<!--  end footer -->
<!-- jquery -->
@include('depan.bagian.script')
<script type="text/javascript" src="https://widget.kominfo.go.id/gpr-widget-kominfo.min.js"></script>
<!-- end jquery -->
</body>
<!--body end -->
</html>


