<html lang="en">
<!-- <![endif]-->
<!-- head -->
<head>
<title>Website Resmi Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu Kabupaten Situbondo | {{$halaman->nama}}</title>
@include('depan.bagian.css_favicon')
<!-- custom css -->
<!-- end theme style -->
</head>
<!-- end head -->
<!--body start-->
<body>
<!-- preloader --> 
@include('depan.bagian.header')
<!-- end preloader --> 
<!--  top bar -->
  
 <div id="page-banner" class="page-banner-main" style="background-image: url('../gambar/frontend/dpmptsp-header-1.jpg')">
    <div class="container">
      <div class="page-banner-block">
        <div class="section">
          <h3 class="section-heading">{{$halaman->nama}}</h3>
        </div>
        <ol class="breadcrumb">
          <li><a href="{{url('/')}}" style="font-weight: bold;">HOME</a></li>
          <li class="active"><a>{{$halaman->nama}}</a></li>
        </ol>
      </div>
    </div>
  </div>
<!--  end page banner  -->
<!-- blog right -->    
  <div id="blog-right" class="blog-page blog-left-main-block blog-right-main-block">
    <div class="container">
      <div class="row">        
        <div class="col-sm-9">
        	
          <div class="news-block">
            <div class="news-img">
                  
            </div>
			<div class="news-dtl">
				{!!$halaman->isi!!}
			</div>
          </div>    
        </div>
        
       			
          
                  
          
      
        <div class="col-sm-3">
          <div class="archives-widget">
            <h6>KATEGORI</h6>
            <div class="archives-content">
              <ul>
                <li><a href="{{ url('/berita')}}"><i class="fa fa-caret-right"></i>Berita</a></li>
                <li><a href="{{ url('/informasi')}}"><i class="fa fa-caret-right"></i>Informasi</a></li>
              </ul>
            </div>
          </div>           

          <div class="tab-widget">
            <h6>Berita Terbaru</h6>
     
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active">
              	@foreach($posts as $post)
                <div class="tab-widget-dtl">
                  <div class="tab-thumb">
                    <img src="{{asset($post->gambar)}}" class="img-responsive" alt="{{$post->judul}}">
                  </div>
                  <a href="{{url('/berita/'.$post->slug)}}">{{$post->judul}}</a>
                </div>                
                @endforeach
              </div>
             </div>
            </div>
            <div class="tab-widget">
            <h6>Informasi Terbaru</h6>
     
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active">
               @foreach($infos as $info)
                <div class="tab-widget-dtl">
                  <div class="tab-thumb">
                    <img src="{{asset($info->gambar)}}" class="img-responsive" alt="{{$info->judul}}">
                  </div>
                  <a href="{{url('/informasi/'.$info->slug)}}">{{$info->judul}}</a>
                </div>                
                @endforeach
              </div>
             </div>
            </div>


          <div class="tag-widget">
            <h6>DPMPTSP Tagline</h6>
            <div class="tags">
              <a href="#"><span class="badge">dpmptsp situbondo</span></a>
              <a href="#"><span class="badge">berita situbondo</span></a>
              <a href="#"><span class="badge">informasi situbondo</span></a>
              <a href="#"><span class="badge">website dpmptsp</span></a>
               <a href="#"><span class="badge">perizinan dpmptsp</span></a>
   
            </div>       
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- The Modal -->
  <div class="modal fade" id="myModal">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">DPMPTSP KABUPATEN SITUBONDO</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
          <div class="embed-responsive embed-responsive-16by9">
            <iframe id="declinedframe" height="100%" src="https://cdn.dribbble.com/users/1186261/screenshots/3718681/_______.gif"></iframe>
          </div>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>


<!--  end latest news -->
<!--  clients -->
@include('depan.bagian.footer')
<!--  end map -->
<!--  footer -->

<!--  end footer -->
<!-- jquery -->
@include('depan.bagian.script')
<script type="text/javascript" src="https://widget.kominfo.go.id/gpr-widget-kominfo.min.js"></script>
<!-- end jquery -->
</body>
<!--body end -->
</html>


  <script type="text/javascript">
        function klik_view(url_file) {
           $('#declinedframe').attr('src', url_file);
           $('#myModal').modal({ show: true });
        }
  </script>