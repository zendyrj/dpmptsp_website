<html lang="en">
<!-- <![endif]-->
<!-- head -->
<head>
<title>Website Resmi Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu Kabupaten Situbondo | Informasi</title>
@include('depan.bagian.css_favicon')
<!-- custom css -->
<!-- end theme style -->
</head>
<!-- end head -->
<!--body start-->
<body>
<!-- preloader --> 
@include('depan.bagian.header')
<!-- end preloader --> 
<!--  top bar -->
  
 <div id="page-banner" class="page-banner-main" style="background-image: url('gambar/frontend/dpmptsp-header-1.jpg')">
    <div class="container">
      <div class="page-banner-block">
        <div class="section">
          <h3 class="section-heading">Informasi Terbaru</h3>
        </div>
        <ol class="breadcrumb">
          <li><a href="{{url('/')}}" style="font-weight: bold;">HOME</a></li>
          <li class="active"><a>Berita</a></li>
        </ol>
      </div>
    </div>
  </div>
<!--  end page banner  -->
<!-- blog right -->    
  <div id="blog-right" class="blog-page blog-left-main-block blog-right-main-block">
    <div class="container">
      <div class="row">        
        <div class="col-sm-9">
        	@foreach($list as $info)
          <div class="news-block">
            <div class="news-img">
              <a href="{{url('informasi/'.$info->slug)}}"><img src="{{asset($info->gambar)}}" class="img-responsive" alt="{{$info->judul}}">      
              <div class="overlay-bg"></div>          
              </a>
            </div>
            <div class="news-top">
              <div class="news-date text-center">
              	<?php
			        $tgl = date('d', strtotime($info->tgl_buat));
			        $bln = date('M', strtotime($info->tgl_buat));
			          ?>
                <h4 class="news-day">{{$tgl}}</h4>
                <div class="news-month">{{$bln}}</div>
              </div>
              <div class="news-heading-block">
                <a href="{{url('informasi/'.$info->slug)}}"><h6 class="news-heading">{{$info->judul}}</h6></a>
                
              </div>
            </div>
            <div class="news-dtl">
               {!! Str::words($info->info, 5,' ....</p>')  !!}
              <a href="{{url('informasi/'.$info->slug)}}" class="btn btn-default">Baca Selengkapnya ...</a>
            </div>
          </div>
          @endforeach
          
          <hr>          
          <div class="pagination-block text-center">
            <div class="row">  
              {{ $list->links() }}
            </div>
          </div>
        </div>
        <div class="col-sm-3">
          <div class="archives-widget">
            <h6>KATEGORI</h6>
            <div class="archives-content">
              <ul>
                <li><a href="{{ url('/berita')}}"><i class="fa fa-caret-right"></i>Berita</a></li>
                <li><a href="{{ url('/informasi')}}"><i class="fa fa-caret-right"></i>Informasi</a></li>
              </ul>
            </div>
          </div>           

          <div class="tab-widget">
            <h6>Berita Terbaru</h6>
     
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active">
              	@foreach($posts as $post)
                <div class="tab-widget-dtl">
                  <div class="tab-thumb">
                    <img src="{{asset($post->gambar)}}" class="img-responsive" alt="{{$post->judul}}">
                  </div>
                  <a href="{{url('/berita/'.$post->slug)}}">{{$post->judul}}</a>
                </div>                
                @endforeach
              </div>
             </div>
            </div>
            <div class="tab-widget">
            <h6>Informasi Terbaru</h6>
     
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active">
               @foreach($infos as $info)
                <div class="tab-widget-dtl">
                  <div class="tab-thumb">
                    <img src="{{asset($info->gambar)}}" class="img-responsive" alt="{{$info->judul}}">
                  </div>
                  <a href="{{url('/informasi/'.$info->slug)}}">{{$info->judul}}</a>
                </div>                
                @endforeach
              </div>
             </div>
            </div>


          <div class="tag-widget">
            <h6>DPMPTSP Tagline</h6>
            <div class="tags">
              <a href="#"><span class="badge">dpmptsp situbondo</span></a>
              <a href="#"><span class="badge">berita situbondo</span></a>
              <a href="#"><span class="badge">informasi situbondo</span></a>
              <a href="#"><span class="badge">website dpmptsp</span></a>
               <a href="#"><span class="badge">perizinan dpmptsp</span></a>
   
            </div>       
          </div>
        </div>
      </div>
    </div>
  </div>


<!--  end latest news -->
<!--  clients -->
@include('depan.bagian.footer')
<!--  end map -->
<!--  footer -->

<!--  end footer -->
<!-- jquery -->
@include('depan.bagian.script')
<script type="text/javascript" src="https://widget.kominfo.go.id/gpr-widget-kominfo.min.js"></script>
<!-- end jquery -->
</body>
<!--body end -->
</html>