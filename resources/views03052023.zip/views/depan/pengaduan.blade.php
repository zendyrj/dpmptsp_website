<html lang="en">
<!-- <![endif]-->
<!-- head -->
<head>
<title>Website Resmi Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu Kabupaten Situbondo | Pengaduan</title>
<meta name="csrf-token" content="{{ csrf_token() }}">
@include('depan.bagian.css_favicon')
<!-- custom css -->
<link href="{{asset('admin/global/plugins/datatables/datatables.min.css')}}" rel="stylesheet" type="text/css" />
<link href="{{asset('admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.css')}}" rel="stylesheet" type="text/css" />
<link href="http://dpmptsp.situbondokab.go.id/admin/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
<!-- end theme style -->
</head>
<!-- end head -->
<!--body start-->
<body>
<!-- preloader --> 
@include('depan.bagian.header')
<!-- end preloader --> 
<!--  top bar -->
  
 <div id="page-banner" class="page-banner-main" style="background-image: url('gambar/frontend/dpmptsp-header-1.jpg')">
    <div class="container">
      <div class="page-banner-block">
        <div class="section">
          <h3 class="section-heading">Pengaduan</h3>
        </div>
        <ol class="breadcrumb">
          <li><a href="{{url('/')}}" style="font-weight: bold;">HOME</a></li>
          <li class="active"><a>Pengaduan</a></li>
        </ol>
      </div>
    </div>
  </div>
<!--  end page banner  -->
<!-- blog right -->    
    <div id="contact-page" class="contact-page-main-block">
    <div class="section text-center">
      <h3 class="section-heading">Pusat Layanan Pengaduan Masyarakat</h3>
      <p class="sub-heading">Harap diisi dengan lengkap dan benar. <br> Pengaduan anda akan ditangani semestinya.</p>
    </div>
    <div class="container">
      <div class="row">
        <div class="col-sm-4"> 
          <div class="contact-block">
            <ul style="font-size: 13px">
              <li><i class="fa fa-phone" aria-hidden="true"></i><a href="#">{{$almt->telepon}}</a></li>
              <li><i class="fa fa-mobile-phone" aria-hidden="true"></i><a href="#">{{$almt->telepon}}</a></li>
              <li><i class="fa fa-map-marker" aria-hidden="true"></i><a href="#">{{$almt->alamat}}</a></li>
              <li><i class="fa fa-envelope-o" aria-hidden="true"></i><a href="#">{{$almt->email}}</a></li>
              <li><i class="fa fa-globe" aria-hidden="true"></i><a href="{{ url('/')}}">dpmptsp.situbondokab.go.id</a></li>
            </ul>
          </div>
        </div>
        <div class="col-sm-8">
        @if(session()->has('message'))
        <div class="alert alert-success alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            {{ session()->get('message') }}
        </div>
        @endif

        @if(count($errors)>0)
          <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            Periksa kembali data isian, mungkin ada yang salah /tidak lengkap.<br/>
         
          </div>
        @endif
          <form id="contact-form" class="contact-form" method="post" action="{{url('pengaduan-dpmptsp')}}" enctype="multipart/form-data">
            {{ csrf_field() }}
        	<div class="form-group">
              <input type="text" maxlength="16" required minlength="16" class="form-control" id="nik" name="nik" placeholder="Nomer Induk Penduduk 16 Karakter">
            </div>

            <div class="form-group">
              <input type="text" class="form-control" name="nama" placeholder="Nama Lengkap">
            </div>
      
         
            <div class="form-group">
              <input type="text" class="form-control" minlength="8" name="telp" placeholder="Nomer Telepon Minimal 8 Karakter">
            </div>
            
          
            <div class="form-group">
              <input type="text" class="form-control" name="subject" id="subject" placeholder="Judul Laporan">
            </div> 
            <div class="message">
              <textarea id="message" name="laporan" rows="6" placeholder="Masukan Laporan Anda di sini"></textarea>
            </div>
            <div class="form-group">
              	<input type="file" class="form-control" accept="image/*,application/pdf" name="file" id="file" placeholder="Upload Dokumen">
            </div>
            <span class="label label-primary"><b style="color: #e3f112">TIDAK WAJIB DI ISI</b> : Hanya untuk file Gambar dan PDF, maksimal ukuran 5MB</span>

            <button type="submit" class="btn btn-default">Kirim</button>              
          </form> 
        </div>
      </div>
    </div>

  <!-- List Pengaduan -->
   <hr>
    <div class="section text-center">
      <h3 class="section-heading">LIST PENGADUAN MASYARAKAT</h3>
      <p class="sub-heading">Harap diisi dengan lengkap dan benar. <br> Pengaduan anda akan ditangani semestinya.</p>
    </div>
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="portlet-body">
            <div class="table-responsive">
                <table class="table table-striped table-bordered table-hover table-header-fixed" id="sample_1">
                    <thead>
                        <tr style="background-image: linear-gradient(#02bae4, #c0f3f3);">
                            <th> No </th>
                            <th> Judul Pengaduan </th>
                            <th> Pelapor </th>
                            <th> Nomer Telp </th>
                           
                            <th> Isi Laporan </th>
                            <th> Tanggal Laporan </th>
                            <th> Aksi </th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $x=1; ?>
                    @foreach($aduan as $aduan)
                        <tr style="background: #f1f1f1">
                            <td> {{$x++}} </td>
                            <td> {{$aduan->subject}} </td>
                            <td><span class="label label-danger">Nama Dirahasiakan</span> </td>
                            <td> {{substr($aduan->telp,0,-5)}}XXXXX </td>
                           
                            <td> {{$aduan->laporan}} </td>
                            <?php
                              $tgl = date('d F Y', strtotime($aduan->created_at));
                              
                            ?>
                            <td> {{$tgl}} </td>
                            <td>
                                <button type="button" onclick="ajax('{{$aduan->id}}')" class="btn-xs btn-info btn-lg" data-toggle="modal" data-target="#myModal">Lihat <i class="fa fa-reply"></i></button>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div> 
        </div>
      </div>
    </div>
  </div>

  <!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">

    <!-- Modal content-->
    <div class="modal-content" id="isi-ajax">
      
    </div>

  </div>
</div>


<!--  end latest news -->
<!--  clients -->
@include('depan.bagian.footer')
<!--  end map -->
<!--  footer -->

<!--  end footer -->
<!-- jquery -->
@include('depan.bagian.script')
<script src="http://dpmptsp.situbondokab.go.id/admin/global/scripts/app.min.js" type="text/javascript"></script>
            <!-- END THEME GLOBAL SCRIPTS -->
            <!-- BEGIN THEME LAYOUT SCRIPTS -->
            <script src="http://dpmptsp.situbondokab.go.id/admin/layouts/layout2/scripts/layout.js" type="text/javascript"></script>
            <!-- END THEME LAYOUT SCRIPTS -->
            <script src="http://dpmptsp.situbondokab.go.id/admin/global/scripts/datatable.js" type="text/javascript"></script>
<script src="http://dpmptsp.situbondokab.go.id/admin/global/plugins/datatables/datatables.min.js" type="text/javascript"></script>
<script src="http://dpmptsp.situbondokab.go.id/admin/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js" type="text/javascript"></script>
<script src="http://dpmptsp.situbondokab.go.id/admin/pages/scripts/table-datatables-fixedheader.min.js" type="text/javascript"></script>
<script type="text/javascript" src="https://widget.kominfo.go.id/gpr-widget-kominfo.min.js"></script>

<script type="text/javascript">
  $.ajaxSetup({
      headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      }
  });

  function ajax(id) {
    $.ajax({
      url : "{{url('pengaduan-ajax')}}",
      type : "post",
      data : {id:id},
      success : function(report) {
        $("#isi-ajax").html(report);
      }
    });
  }

   $("#nik").on("keypress keyup blur",function (event) {    
       $(this).val($(this).val().replace(/[^\d].+/, ""));
        if ((event.which < 48 || event.which > 57)) {
            event.preventDefault();
        }
    });
</script>
<!-- end jquery -->
</body>
<!--body end -->
</html>


