<html lang="en">
<!-- <![endif]-->
<!-- head -->
<head>
<title>Website Resmi Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu Kabupaten Situbondo </title>
@include('depan.bagian.css_favicon')
<!-- custom css -->
<!-- end theme style -->
</head>
<!-- end head -->
<!--body start-->
<body>
<!-- preloader --> 
@include('depan.bagian.header')
<!-- end preloader --> 
<!--  top bar -->
  
 <div id="page-banner" class="page-banner-main" style="background-image: url('../gambar/frontend/dpmptsp-header-1.jpg')">
    <div class="container">
      <div class="page-banner-block">
        <div class="section">
          <h3 class="section-heading">Alur Layanan Pengaduan</h3>
        </div>
        <ol class="breadcrumb">
          <li><a href="{{url('/')}}" style="font-weight: bold;">HOME</a></li>
          <li class="active"><a>Alur Layanan Pengaduan</a></li>
        </ol>
      </div>
    </div>
  </div>
<!--  end page banner  -->
<!-- blog right -->    
  <div id="blog-right" class="blog-page blog-left-main-block blog-right-main-block">
    <div class="container">
      <div class="row">        
        <div class="col-sm-9">
        	
          <div class="news-block">
            <div class="news-img">
                  
            </div>
			<div class="news-heading-block">
                <h6 class="news-heading">Alur Pengaduan DPMPTSP Kabupaten Situbondo</h6>
                
              </div>
				<div class="news-dtl">
<p>&nbsp;</p>
<center><h3>Alur Pengaduan(Manual) DPMPTSP</h3></center><br>
<center><h3>Kabupaten Situbondo</h3></center>
<img src="http://dpmptsp.situbondokab.go.id/gambar/sop_pengaduan/SOP MANUAL.jpg" class="img-responsive" alt="Alur Pengaduan(Manual) DPMPTSP Kabupaten Situbondo">
<table style="width: 724.993px;">
<tbody>
<tr>
<td style="width: 112px;">
<p>Persyaratan</p>
</td>
<td style="width: 18px;">
<p>:</p>
</td>
<td style="width: 574.993px;">
<p style="text-align: justify;">Membuat surat pengaduan atau mengisi formulir pengaduan tentang</p>
</td>
</tr>
<tr>
<td style="width: 112px;">
<p>&nbsp;</p>
</td>
<td style="width: 18px;">
<p>&nbsp;</p>
</td>
<td style="width: 574.993px;">
<p style="text-align: justify;">perizinan ditujukan kepada Kepala Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu dengan melampirkan identitas diri;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
</td>
</tr>
<tr>
<td style="width: 112px;">
<p>Prosedur</p>
</td>
<td style="width: 18px;">
<p>:</p>
</td>
<td style="width: 574.993px;">
<p style="text-align: justify;">a.&nbsp;&nbsp;&nbsp; Pelapor membuat surat pengaduan atau mengisi formulir pengaduan ditujukan kepada Kepala Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu (DPMPTSP) dengan melampirkan identitas diri;</p>
</td>
</tr>
<tr>
<td style="width: 112px;">
<p>&nbsp;</p>
</td>
<td style="width: 18px;">
<p>:</p>
</td>
<td style="width: 574.993px;">
<p style="text-align: justify;">b.&nbsp;&nbsp;&nbsp; Subbag Umum dan Kepegawaian menerima dan memasukkan surat pengaduan atau formulir pengaduan ke agenda surat serta memberi lembar disposisi untuk disediakan pada Kepala Dinas;</p>
<p style="text-align: justify;">c.&nbsp;&nbsp;&nbsp; Kepala Dinas memberikan disposisi kepada Kepala Bidang Data, Informasi dan Pengaduan untuk ditindaklanjuti;</p>
<p style="text-align: justify;">d.&nbsp;&nbsp;&nbsp; Kepala Bidang Data, Informasi dan Pengaduan mendisposisi surat pengaduan kepada Kepala Seksi Penanganan Pengaduan untuk dipelajari;</p>
<p style="text-align: justify;">e.&nbsp;&nbsp;&nbsp; Kepala Seksi Penanganan Pengaduan menentukan pengaduan berdasarkan kewenangan;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Pengaduan bukan kewenangan DMPTSP;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Pengaduan kewenangan DPMPTSP;</p>
<p style="text-align: justify;">f.&nbsp;&nbsp;&nbsp;&nbsp; Apabila pengaduan bukan kewenangan DPMPTS</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kepala Seksi Penanganan Pengaduan meneruskan pengaduan dengan membuat surat kepada OPD terkait atau pihak lain yang mempunyai kewenangan atas pengaduan dengan tembusan kepada pihak pengadu;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kepala Seksi Penanganan Pengaduan menyediakan konsep surat yang akan diteruskan pada OPD terkait atau pihak lain kepada Kepala Bidang Data, Informasi dan Pengaduan;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kepala Bidang Data, Informasi dan Pengaduan mengoreksi dan memberikan persetujuan dengan membubuhkan paraf pada surat untuk disediakan kepada Kepala Dinas;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kepala Dinas menandatangani surat yang ditujukan kepada OPD terkait atau pihak lain dengan tembusan pihak pengadu;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Staf Penanganan Pengaduan menyampaikan surat kepada OPD terkait atau pihak lain dan menyampaikan tembusan surat kepada pihak pengadu;</p>
<p style="text-align: justify;">g.&nbsp;&nbsp;&nbsp; Apabila pengaduan merupakan kewenangan DPMPTSP :</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kepala Seksi Penanganan Pengaduan memerintahkan staf seksi Penanganan Pngaduan untuk mengecek data perizinan atas obyek aduan;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Staf seksi Penanganan Pengaduan melaporkan hasil pengecekan data perizinan kepada Kepala Seksi Penanganan Pengaduan;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kepala Seksi Penanganan Pengaduan menganalisa hasil cek data perizinan dan mengkonsultasikannya kepada Kepala Bidang Data, Informasi dan Pengaduan;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kepala Bidang Data, Informasi dan Pengaduan mengkoordinasikan dengan Kepala Bidang Pelayanan Terpadu terkait perizinan;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kepala Bidang Data, Informasi dan Pengaduan menyampaikan hasil koordinasi dan analisa kepada Kepala Dinas Penanaman Modal Dan Pelayanan Terpadu satu Pintu;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kepala Dinas memberikan arahan terkait tindaklanjut pengaduan;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kepala Bidang Data, Informasi dan Pengaduan memerintahkan Kasi Penanganan Pengaduan selaku pengelola pengaduan untuk melakukan penanganan pengaduan sesuai arahan;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kepala Seksi Penanganan Pengaduan melaksanakan penanganan pengaduan dan memfasilititasi pengaduan;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kepala Seksi Penanganan Pengaduan membuat &nbsp;konsep surat jawaban kepada pihak pengadu tentang tindak lanjut yang sudah dilakukan;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kepala Bidang Data, Informasi dan Pengaduan mengoreksi dan memberikan persetujuan dengan membubuhkan paraf pada surat jawaban kepada pihak pengadu tentang tindaklanjut yang sudah dilakukan;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kepala Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu menandatangani surat jawaban kepada pihak pengadu tentang tindak lanjut yang sudah dilakukan;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Staf seksi Penanganan Pengaduan menyampaikan dan mengarsip surat jawaban kepada pihak pengadu tentang tindaklanjut yang sudah dilakukan.</p>
</td>
</tr>
</tbody>
</table>
<hr>
<center><h3>Alur Pengaduan(Website) DPMPTSP</h3></center><br>
<center><h3>Kabupaten Situbondo</h3></center>
<img src="http://dpmptsp.situbondokab.go.id/gambar/sop_pengaduan/SOP WEBSITE.jpg" class="img-responsive" alt="Alur Pengaduan(Website) DPMPTSP Kabupaten Situbondo">
<table style="width: 712.146px;">
<tbody>
<tr>
<td style="width: 112px;">
<p>Persyaratan</p>
</td>
<td style="width: 18px;">
<p>:</p>
</td>
<td style="width: 562.146px;">
<p style="text-align: justify;">Menyampaikan pengaduan melalui website Dinas Penanaman&nbsp;&nbsp;Modal Dan&nbsp;&nbsp;&nbsp;&nbsp;</p>
</td>
</tr>
<tr>
<td style="width: 112px;">
<p>&nbsp;</p>
</td>
<td style="width: 18px;">
<p>&nbsp;</p>
</td>
<td style="width: 562.146px;">
<p style="text-align: justify;">Pelayanan Terpadu Satu Pintu Kabupaten Situbondo Pintu dengan memberikan identitas diri;</p>
</td>
</tr>
<tr>
<td style="width: 112px;">
<p>Prosedur</p>
</td>
<td style="width: 18px;">
<p>:</p>
</td>
<td style="width: 562.146px;">
<p style="text-align: justify;">a.&nbsp;&nbsp;&nbsp; Pelapor menyampaikan pengaduannya melalui website Dinas&nbsp;Penanaman Modal dan Pelayanan Terpadu Satu Pintu (DPMPTSP) dengan&nbsp; memberikan identitas diri;</p>
</td>
</tr>
<tr>
<td style="width: 112px;">
<p>&nbsp;</p>
</td>
<td style="width: 18px;">
<p>:</p>
</td>
<td style="width: 562.146px;">
<p style="text-align: justify;">b.&nbsp;&nbsp;&nbsp; Petugas penerima pengaduan menyampaikan screenshoot pengaduan melalui website kepada Kepala Seksi Penanganan Pengaduan selaku pengelola pengaduan;</p>
<p style="text-align: justify;">c.&nbsp;&nbsp;&nbsp; Kepala Seksi Penanganan Pengaduan memberikan screenshot pengaduan melalui website kepada Subbag Umum dan Kepegawaian untuk disediakan kepada Kepala Dinas;</p>
<p style="text-align: justify;">d.&nbsp;&nbsp;&nbsp; Subbag Umum dan Kepegawaian menerima dan memasukkan screenshot pengaduan melalui website &nbsp;ke agenda surat serta memberi lembar disposisi untuk disediakan pada Kepala Dinas;</p>
<p style="text-align: justify;">e.&nbsp;&nbsp;&nbsp; Kepala Dinas memberikan disposisi kepada Kepala Bidang Data, Informasi dan Pengaduan untuk ditindaklanjuti;</p>
<p style="text-align: justify;">f.&nbsp;&nbsp;&nbsp;&nbsp; Kepala Bidang Data, Informasi dan Pengaduan mendisposisi pengaduan melalui website kepada Kepala Seksi Penanganan Pengaduan untuk dipelajari;</p>
<p style="text-align: justify;">g.&nbsp;&nbsp;&nbsp; Kepala Seksi Penanganan Pengaduan menentukan pengaduan berdasarkan kewenangan;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Pengaduan bukan kewenangan DMPTSP;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Pengaduan kewenangan DPMPTSP;</p>
<p style="text-align: justify;">h.&nbsp;&nbsp; Apabila pengaduan bukan kewenangan DPMPTS</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kepala Seksi Penanganan Pengaduan memerintahkan kepada petugas penerima pengaduan untuk menanggapi pengaduan melalui website bahwa pengaduan tersebut akan diteruskan kepada OPD terkait atau pihak lain dan membuat surat kepada OPD terkait atau pihak lain yang mempunyai kewenangan terhadap pengaduan;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Petugas penerima pengaduan menjawab melalui website bahwa pengaduan bukan kewenangan DPMPTSP dan pengaduan akan diteruskan kepada OPD terkait atau pihak lain yang mempunai kewenangan terhadap pengaduan;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kepala Seksi Penanganan Pengaduan menyediakan konsep surat yang akan diteruskan pada OPD terkait atau pihak lain kepada Kepala Bidang Data, Informasi dan Pengaduan;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kepala Bidang Data, Informasi dan Pengaduan mengoreksi dan memberikan persetujuan dengan membubuhkan paraf pada surat untuk disediakan kepada Kepala Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kepala Dinas Pelayanan Terpadu Satu &nbsp;&nbsp;Pintu menandatangani surat yang ditujukan kepada OPD terkait atau pihak lain;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Staf Penanganan Pengaduan menyampaikan surat kepada OPD terkait atau pihak lain;</p>
<p style="text-align: justify;">i.&nbsp;&nbsp;&nbsp;&nbsp; Apabila pengaduan merupakan kewenangan DPMPTSP :</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kepala Seksi Penanganan Pengaduan memerintahkan staf seksi Penanganan Pngaduan untuk mengecek data perizinan atas obyek aduan;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Staf seksi Penanganan Pengaduan melaporkan hasil pengecekan data perizinan kepada Kepala Seksi Penanganan Pengaduan;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kepala Seksi Penanganan Pengaduan menganalisa hasil cek data perizinan dan mengkonsultasikannya kepada Kepala Bidang Data, Informasi dan Pengaduan;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kepala Bidang Data, Informasi dan Pengaduan mengkoordinasikan dengan Kepala Bidang Pelayanan Terpadu terkait perizinan;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kepala Bidang Data, Informasi dan Pengaduan &nbsp;menyampaikan hasil koordinasi dan analisa kepada Kepala Dinas; Kepala Dinas memberikan arahan terkait tindaklanjut pengaduan;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kepala Bidang Data, Informasi dan Pengaduan memerintahkan Kasi Penanganan Pengaduan selaku pengelola pengaduan untuk melakukan penanganan pengaduan sesuai arahan;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kepala Seksi Penanganan Pengaduan melaksanakan tindaklanjut pengaduan;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kepala Seksi Penanganan Pengaduan membuat konsep jawaban atas pengaduan kepada pelapor;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kepala Bidang Data, Informasi dan Pengaduan mengoreksi dan memberikan persetujun atas&nbsp; jawaban atas pengaduan kepada pelapor;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kepala Dinas menyetujui konsep jawaban atas pengaduan kepada pelapor;</p>
<p style="text-align: justify;">-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Staf seksi Penanganan Pengaduan menjawab melalui website terkait penanganan pengaduan.</p>
</td>
</tr>
</tbody>
</table>
<h2>&nbsp;</h2>
<h2>Media Layanan Pengaduan :</h2>
<p>&nbsp;</p>
<ul style="list-style-type: disc;">
<li>
<h3>Surat</h3>
</li>
<li>
<h3>Kotak Pengaduan</h3>
</li>
<li>
<h3>Formulir Pengaduan</h3>
</li>
<li>
<h3>Website :&nbsp;<a title="Website" href="/">dpmptsp.situbondokab.go.id</a></h3>
</li>
</ul>
              
            </div>
          </div>    
        </div>
       			
          
                  
          
      
        <div class="col-sm-3">
          <div class="archives-widget">
            <h6>KATEGORI</h6>
            <div class="archives-content">
              <ul>
                <li><a href="{{ url('/berita')}}"><i class="fa fa-caret-right"></i>Berita</a></li>
                <li><a href="{{ url('/informasi')}}"><i class="fa fa-caret-right"></i>Informasi</a></li>
              </ul>
            </div>
          </div>           

          <div class="tab-widget">
            <h6>Berita Terbaru</h6>
     
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active">
              	@foreach($posts as $post)
                <div class="tab-widget-dtl">
                  <div class="tab-thumb">
                    <img src="{{asset($post->gambar)}}" class="img-responsive" alt="{{$post->judul}}">
                  </div>
                  <a href="{{url('/berita/'.$post->slug)}}">{{$post->judul}}</a>
                </div>                
                @endforeach
              </div>
             </div>
            </div>
            <div class="tab-widget">
            <h6>Informasi Terbaru</h6>
     
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active">
               @foreach($infos as $info)
                <div class="tab-widget-dtl">
                  <div class="tab-thumb">
                    <img src="{{asset($info->gambar)}}" class="img-responsive" alt="{{$info->judul}}">
                  </div>
                  <a href="{{url('/informasi/'.$info->slug)}}">{{$info->judul}}</a>
                </div>                
                @endforeach
              </div>
             </div>
            </div>


          <div class="tag-widget">
            <h6>DPMPTSP Tagline</h6>
            <div class="tags">
              <a href="#"><span class="badge">dpmptsp situbondo</span></a>
              <a href="#"><span class="badge">berita situbondo</span></a>
              <a href="#"><span class="badge">informasi situbondo</span></a>
              <a href="#"><span class="badge">website dpmptsp</span></a>
               <a href="#"><span class="badge">perizinan dpmptsp</span></a>
   
            </div>       
          </div>
        </div>
      </div>
    </div>
  </div>


<!--  end latest news -->
<!--  clients -->
@include('depan.bagian.footer')
<!--  end map -->
<!--  footer -->

<!--  end footer -->
<!-- jquery -->
@include('depan.bagian.script')
<script type="text/javascript" src="https://widget.kominfo.go.id/gpr-widget-kominfo.min.js"></script>
<!-- end jquery -->
</body>
<!--body end -->
</html>


