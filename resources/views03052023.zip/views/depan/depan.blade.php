<html lang="en">
<!-- <![endif]-->
<!-- head -->
<head>
<title>Website Resmi Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu Kabupaten Situbondo</title>
@include('depan.bagian.css_favicon')
<!-- custom css -->
<!-- end theme style -->
</head>
<!-- end head -->
<!--body start-->
<body>
<!-- preloader --> 
@include('depan.bagian.header')
<!-- end preloader --> 
<!--  top bar -->
  
<!--  end navigation -->
<!--  slider -->
  <div id="home-slider" class="home-slider">
    <div class="item home-slider-bg" style="background-image: url('gambar/frontend/pelayanan_gratis.png');background-size: 1274px 660px;"> 
      <div class="container">
        <div class="slider-dtl">
          <h4 class="slider-sub-heading">Selamat Datang</h4>
          <h1 class="slider-heading" style="font-size: 32px">di Website DPMPTSP Kabupaten Situbondo</h1>
          <div class="slider-btn">
             <p>Jalan PB Sudirman Nomer 20 Kabupaten Situbondo</p>
          </div>
        </div>  
      </div>     
    </div>
   <!--  <div class="item home-slider-bg" style="background-image: url('gambar/frontend/dpmptsp-slider-3.jpg')">  
      <div class="container">
        <div class="slider-dtl">
          <h4 class="slider-sub-heading">Selamat Datang</h4>
          <h1 class="slider-heading" style="font-size: 32px">di Website DPMPTSP Kabupaten Situbondo</h1>
          <div class="slider-btn">
             <p>Jalan PB Sudirman Nomer 20 Kabupaten Situbondo</p>
          </div>
        </div>  
      </div>      
    </div> -->
    
    <div class="item home-slider-bg" style="background-image: url('gambar/frontend/dpmptsp-slider-2.jpg')">  
      <div class="container">
        <div class="slider-dtl">
          <h4 class="slider-sub-heading">Selamat Datang</h4>
          <h1 class="slider-heading" style="font-size: 32px">di Website DPMPTSP Kabupaten Situbondo</h1>
          <div class="slider-btn">
             <p>Jalan PB Sudirman Nomer 20 Kabupaten Situbondo</p>
          </div>
        </div>  
      </div>      
    </div>
     <div class="item home-slider-bg" style="object-fit: cover;background-image: url('gambar/frontend/dpmptsp-slider-3.png')">  
      <div class="container">
        <div class="slider-dtl">
          <h4 class="slider-sub-heading">Nyara Investasi</h4>
          <h1 class="slider-heading" style="font-size: 32px">di Kabupaten Situbondo</h1>
          <div class="slider-btn">
             <p>Kemudahan Perizinan, Keringanan atau Pembebasan Pajak dan Retribusi Daerah, serta Kenyamanan dan Keamanan Berinvestasi</p>
          </div>
        </div>  
      </div>      
    </div>
    
  </div>
<!--  end slider -->

<div id ="who-we-are" class="who-we-are-main-block" style="background: #e1e4e8;">
    <div class="container" style="background: linear-gradient(110deg, #e1e4e8 30%, #fff 30%);">
      <div class="row">
        <div class="col-md-12">
          <div class="section">
            <h3 class="section-heading">LAYANAN PERIZINAN GRATIS</h3>
            <p><b>Layanan Perizinan</b> <b style="color: red">GRATIS</b> <b>(Tanpa dipungut Biaya)</b><br><b style="color: red">KECUALI</b> <b>perizinan tertentu yang mempersyaratkan pembayaran retribusi, Seperti IMB, Perikanan, dan Trayek.</b></p>
          </div>
        <div class="col-md-10">
            <img src="{{ asset('gambar/frontend/pelayanan_gratis.png') }}" class="img-responsive" alt="sipinter.situbondokab.go.id" oncontextmenu="return false">
        </div>
      </div>
    </div>
  </div>
</div>
<!--  who we are -->
  <div id ="who-we-are" class="who-we-are-main-block" style="background: #e1e4e8;margin: 0px 0px 5px 0px">
    <div class="container">
      <div class="row">
        <div class="col-md-8">
          <div class="section">
            <h3 class="section-heading">Layanan Terpadu DPMPTSP</h3>
            <p>Dalam rangka mewujudkan Situbondo Smart Society, Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu Kabupaten Situbondo memberikan kemudahan dalam pelayanan dengan menggunakan teknologi informasi yang dikemas dalam portal pelayanan perizinan online DPMPTSP Kabupaten Situbondo.</p>
          </div>
          <div class="row who-we-are-points">
            <div class="col-sm-6">
              <div class="who-we-are-block">
                <div class="who-we-are-icon">
                  <img src="{{asset('gambar/frontend/dpmptsp-home-sipinter-1.png') }}" class="img-responsive">
                </div>
                <div class="who-we-are-dtl">
                  <h5 class="who-we-are-heading">Layanan Perizinan</h5>
                  <p>Pelayanan perizinan secara online</p>
                </div>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="who-we-are-block">
                <div class="who-we-are-icon">
                  <img src="{{asset('gambar/frontend/dpmptsp-home-sipinter-2.png') }}" class="img-responsive">
                </div>
                <div class="who-we-are-dtl">
                  <h5 class="who-we-are-heading">Peta Perizinan</h5>
                  <p>Sebaran Perizinan di Aplikasi Sipinter</p>
                </div>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="who-we-are-block">
                <div class="who-we-are-icon">
                <img src="{{asset('gambar/frontend/dpmptsp-home-sipinter-3.png') }}" class="img-responsive">
                </div>
                <div class="who-we-are-dtl">
                  <h5 class="who-we-are-heading">Monitoring Berkas</h5>
                  <p>Melihat Progress atau status Berkas Perizinan</p>
                </div>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="who-we-are-block">
                <div class="who-we-are-icon">
                  <img src="{{asset('gambar/frontend/dpmptsp-home-sipinter-4.png') }}" class="img-responsive">
                </div>
                <div class="who-we-are-dtl">
                  <h5 class="who-we-are-heading">Call Center</h5>
                  <p>(0338) 672115</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="who-we-are-img">
            <a href="http://sipinter.situbondokab.go.id" target="_blank"><img src="{{ asset('gambar/frontend/dpmptsp-home-sipinter1.png') }}" class="img-responsive" alt="sipinter.situbondokab.go.id"></a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div id ="who-we-are" class="who-we-are-main-block" style="background: #e1e4e8;margin: 0px 0px 5px 0px">
    <div class="container">
      <div class="row">
        <div class="col-md-8">
          <div class="section">
            <h3 class="section-heading">Layanan Klinik OSS</h3>
            <p>Sebagai upaya meningkatkan kualitas pelayanan perizinan dan pemahaman masyarakat akan sistem OSS, maka dpmptsp melakukan Akselerasi Pelayanan Perijinan Berusaha  Melalui Klinik Dokter OSS. Melalui inovasi Akselerasi Pelayanan Perijinan Berusaha  Melalui Klinik Dokter OSS ini telah diadakan ruang khusus yang di sebut Klinik Dokter OSS dan dibentuk Tim yang bertugas memberikan pelayanan perizinan berusaha dengan cara memberikan pemahaman serta bantuan kepada masyarakat dan pelayanan dapat dilakukan secara cepat dan pasti.</p>
          </div>
          <div class="row who-we-are-points">
            <div class="col-sm-6">
              <div class="who-we-are-block">
                <div class="who-we-are-icon">
                  <img src="{{asset('gambar/frontend/dpmptsp-home-sipinter-1.png') }}" class="img-responsive">
                </div>
                <div class="who-we-are-dtl">
                  <h5 class="who-we-are-heading">Datang</h5>
                  <p>Datang</p>
                </div>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="who-we-are-block">
                <div class="who-we-are-icon">
                  <img src="{{asset('gambar/frontend/proses.png') }}" class="img-responsive">
                </div>
                <div class="who-we-are-dtl">
                  <h5 class="who-we-are-heading">Operasikan</h5>
                  <p>Operasikan</p>
                </div>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="who-we-are-block">
                <div class="who-we-are-icon">
                <img src="{{asset('gambar/frontend/konsul.png') }}" class="img-responsive">
                </div>
                <div class="who-we-are-dtl">
                  <h5 class="who-we-are-heading">Konsultasikan</h5>
                  <p>Konsultasikan</p>
                </div>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="who-we-are-block">
                <div class="who-we-are-icon">
                  <img src="{{asset('gambar/frontend/cetak.png') }}" class="img-responsive">
                </div>
                <div class="who-we-are-dtl">
                  <h5 class="who-we-are-heading">Terbitkan</h5>
                  <p>Terbitkan</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="who-we-are-img">
            <a href="http://sipinter.situbondokab.go.id" target="_blank"><img src="{{ asset('gambar/frontend/dpmptsp-home-klinikoss.png') }}" class="img-responsive" alt="sipinter.situbondokab.go.id"></a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div id ="who-we-are" class="who-we-are-main-block" style="background: #e1e4e8;margin: 5px 0px 5px 0px">
    <div class="container">
      <div class="row">
        <div class="col-md-8">
          <div class="section">
            <h3 class="section-heading">POTENSI INVESTASI</h3>
            <p>Dalam rangka mewujudkan Situbondo Smart Society, Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu Kabupaten Situbondo memberikan kemudahan dalam mencari potensi investasi di daerah Kabupaten Situbondo dengan menggunakan teknologi informasi yang dikemas dalam portal potensi investasi online DPMPTSP Kabupaten Situbondo.</p>
          </div>
          <div class="row who-we-are-points">
            <div class="col-sm-6">
              <div class="who-we-are-block">
                <div class="who-we-are-icon">
                  <img src="{{asset('gambar/frontend/dpmptsp-home-sipinter-2.png') }}" class="img-responsive">
                </div>
                <div class="who-we-are-dtl">
                  <h5 class="who-we-are-heading">Peta Potensi Investasi</h5>
                  <p>Sebaran Investasi di Aplikasi Sipoint</p>
                </div>
              </div>
            </div>
            <!-- <div class="col-sm-6">
              <div class="who-we-are-block">
                <div class="who-we-are-icon">
                  <img src="{{asset('gambar/frontend/dpmptsp-home-sipinter-1.png') }}" class="img-responsive">
                </div>
                <div class="who-we-are-dtl">
                  <h5 class="who-we-are-heading">Layanan Perizinan</h5>
                  <p>Pelayanan perizinan secara online</p>
                </div>
              </div>
            </div>
             -->
            <div class="col-sm-6">
              <div class="who-we-are-block">
                <div class="who-we-are-icon">
                <img src="{{asset('gambar/frontend/dpmptsp-home-sipinter-3.png') }}" class="img-responsive">
                </div>
                <div class="who-we-are-dtl">
                  <h5 class="who-we-are-heading">Monitoring Potensi Investasi</h5>
                  <p>Melihat Seluruh Potensi Investasi di Situbondo</p>
                </div>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="who-we-are-block">
                <div class="who-we-are-icon">
                  <img src="{{asset('gambar/frontend/dpmptsp-home-sipinter-4.png') }}" class="img-responsive">
                </div>
                <div class="who-we-are-dtl">
                  <h5 class="who-we-are-heading">Call Center</h5>
                  <p>(0338) 672115</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="who-we-are-img">
            <a href="http://sipoint.situbondokab.go.id" target="_blank"><img src="{{ asset('gambar/frontend/sipoint.png') }}" class="img-responsive" alt="sipoint.situbondokab.go.id"></a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div id ="who-we-are" class="who-we-are-main-block" style="background: #e1e4e8;margin: 5px 0px 5px 0px">
    <div class="container">
      <div class="row">
        <div class="col-md-8">
          <div class="section">
            <h3 class="section-heading">DATA DAN ARSIP PERIZINAN</h3>
            <p>Dalam rangka mewujudkan Situbondo Smart Society, Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu Kabupaten Situbondo memberikan kemudahan dalam mencari data dan arsip perizinan dengan menggunakan teknologi informasi yang dikemas dalam portal data dan arsip perijinan online DPMPTSP Kabupaten Situbondo.</p>
          </div>
          <div class="row who-we-are-points">
            <div class="col-sm-6">
              <div class="who-we-are-block">
                <div class="who-we-are-icon">
                <img src="{{asset('gambar/frontend/dpmptsp-home-sipinter-3.png') }}" class="img-responsive">
                </div>
                <div class="who-we-are-dtl">
                  <h5 class="who-we-are-heading">Monitoring Berkas</h5>
                  <p>Melihat Data dan Arsip Perizinan</p>
                </div>
              </div>
            </div>
            <!-- <div class="col-sm-6">
              <div class="who-we-are-block">
                <div class="who-we-are-icon">
                  <img src="{{asset('gambar/frontend/dpmptsp-home-sipinter-1.png') }}" class="img-responsive">
                </div>
                <div class="who-we-are-dtl">
                  <h5 class="who-we-are-heading">Pencarian Data dan Arsip Perizinan</h5>
                  <p>Pencarian data dan arsip perizinan secara online</p>
                </div>
              </div>
            </div> -->
            <div class="col-sm-6">
              <div class="who-we-are-block">
                <div class="who-we-are-icon">
                  <img src="{{asset('gambar/frontend/dpmptsp-home-sipinter-2.png') }}" class="img-responsive">
                </div>
                <div class="who-we-are-dtl">
                  <h5 class="who-we-are-heading">Peta Perizinan</h5>
                  <p>Sebaran Perizinan di Aplikasi Sipinter</p>
                </div>
              </div>
            </div>
            
            <div class="col-sm-6">
              <div class="who-we-are-block">
                <div class="who-we-are-icon">
                  <img src="{{asset('gambar/frontend/dpmptsp-home-sipinter-4.png') }}" class="img-responsive">
                </div>
                <div class="who-we-are-dtl">
                  <h5 class="who-we-are-heading">Call Center</h5>
                  <p>(0338) 672115</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="who-we-are-img">
            <a href="http://sitajin.situbondokab.go.id" target="_blank"><img src="{{ asset('gambar/frontend/sitajin.png') }}" class="img-responsive" alt="sitajin.situbondokab.go.id"></a>
          </div>
        </div>
      </div>
    </div>
  </div>
<!--  end who we are -->
<!--  services -->

<!--  end appointment -->
<!--  latest news -->
  <div id="news" class="news-main-block">
    <div class="container">
      <div class="section text-center">
        <h3 class="section-heading">Berita Terbaru</h3>
      </div>
      <div class="row">
          @foreach($posts1 as $berita1)
        <div class="col-md-4 col-sm-6">
          <div class="news-block">
            <div class="news-img">
              <a href="{{url('berita/'.$berita1->slug)}}"><img src="{{asset($berita1->gambar)}}" class="img-responsive" alt="{{$berita1->judul}}">
                <div class="overlay-bg"></div>
              </a>
            </div>
            <div class="news-top">
              <div class="news-date text-center">
                 <?php
                    $tgl = date('d', strtotime($berita1->tgl_buat));
                    $bln = date('M', strtotime($berita1->tgl_buat));
                    ?>
                <h4 class="news-day"> {{$tgl}} </h4>
                <div class="news-month"> {{$bln}} </div>
              </div>
              <div class="news-heading-block">
                <a href="{{url('berita/'.$berita1->slug)}}"><h6 class="news-heading">{{$berita1->judul}}</h6></a>
                <ul class="news-tag">
                </ul>
              </div>
            </div>
            <!-- <div class="news-dtl">
              <p>{!! Str::words($berita1->berita, 15,' ...</p>')  !!}</p>
            </div> -->
          </div>
        </div>
          @endforeach
      </div>
      <div class="row">
          @foreach($posts2 as $berita2)
        <div class="col-md-4 col-sm-6">
          <div class="news-block">
            <div class="news-img">
              <a href="{{url('berita/'.$berita2->slug)}}"><img src="{{asset($berita2->gambar)}}" class="img-responsive" alt="{{$berita2->judul}}">
                <div class="overlay-bg"></div>
              </a>
            </div>
            <div class="news-top">
              <div class="news-date text-center">
                 <?php
                    $tgl = date('d', strtotime($berita1->tgl_buat));
                    $bln = date('M', strtotime($berita1->tgl_buat));
                    ?>
                <h4 class="news-day"> {{$tgl}} </h4>
                <div class="news-month"> {{$bln}} </div>
              </div>
              <div class="news-heading-block">
                <a href="{{url('berita/'.$berita2->slug)}}"><h6 class="news-heading">{{$berita2->judul}}</h6></a>
                <ul class="news-tag">
                </ul>
              </div>
            </div>
            <!-- <div class="news-dtl">
              <p>{!! Str::words($berita2->berita, 10,' ....</p>')  !!}</p>
            </div> -->
          </div>
        </div>
          @endforeach
      </div>
    </div>
  </div>

<div id="testimonials" class="testimonials-main-block">
    <div class="parallax" style="background-image: url('gambar/frontend/dpmptsp-situbondo-banner.jpg')">
    <div class="overlay-bg"></div>
      <div class="container">
        <div class="section text-center">
               <p style="color: #63a2e7; font-size: 35px"> DPMPTSP Kabupaten Situbondo</p>  
               <img src="{{asset('gambar/frontend/logo-situbondo.png')}}" class="img-responsive">
        </div>
        <div id="testimonials-slider" class="testimonials-slider">
        
        </div>
      </div>
    </div>
  </div>


   <div id="services" class="services-main-block">
    <div class="container">
      <div class="col-md-8">
        <div class="section text-center">
          <h3 class="section-heading">INFORMASI DPMPTSP</h3>
        </div>
        <div class="row">
          @foreach($infos1 as $info1)
          <div class="col-md-6">
            <div class="service-block text-center">
              <div class="service-icon">
                <a href="{{url('informasi/'.$info1->slug)}}"><img src="{{asset($info1->gambar)}}" alt="{{$info1->judul}}" class="img-responsive"></a>
              </div>
              <div class="service-dtl">
                <a href="{{url('informasi/'.$info1->slug)}}"><h5 class="service-heading">{{$info1->judul}}</h5></a>
                
              </div>
            </div>
          </div>
         @endforeach
       </div>
       <div class="row">
          @foreach($infos2 as $info2)
          <div class="col-md-6">
            <div class="service-block text-center">
              <div class="service-icon">
                <a href="{{url('informasi/'.$info2->slug)}}"><img src="{{asset($info2->gambar)}}" alt="{{$info2->judul}}" class="img-responsive"></a>
              </div>
              <div class="service-dtl">
                <a href="{{url('informasi/'.$info2->slug)}}"><h5 class="service-heading">{{$info2->judul}}</h5></a>
                
              </div>
            </div>
          </div>
         @endforeach
       </div>
      </div>
      <div class="col-md-4"> 
        <div id="gpr-kominfo-widget-container"></div>
      </div>
    </div>
  </div>

<!--  end latest news -->
<!--  clients -->
@include('depan.bagian.footer')
<!--  end map -->
<!--  footer -->

<!--  end footer -->
<!-- jquery -->
@include('depan.bagian.script')
<script type="text/javascript" src="https://widget.kominfo.go.id/gpr-widget-kominfo.min.js"></script>
<!-- end jquery -->
</body>
<!--body end -->
</html>


