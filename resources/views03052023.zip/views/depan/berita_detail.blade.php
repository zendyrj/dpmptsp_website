<html lang="en">
<!-- <![endif]-->
<!-- head -->
<head>
<title>Website Resmi Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu Kabupaten Situbondo | {{$halaman->judul}}</title>
@include('depan.bagian.css_favicon')
<!-- custom css -->
<!-- end theme style -->
</head>
<!-- end head -->
<!--body start-->
<body>
<!-- preloader --> 
@include('depan.bagian.header')
<!-- end preloader --> 
<!--  top bar -->
  
 <div id="page-banner" class="page-banner-main" style="background-image: url('../gambar/frontend/dpmptsp-header-1.jpg')">
    <div class="container">
      <div class="page-banner-block">
        <div class="section">
          <h3 class="section-heading">Berita Terbaru</h3>
        </div>
        <ol class="breadcrumb">
          <li><a href="{{url('/')}}" style="font-weight: bold;">HOME</a></li>
          <li class="active"><a>{{$halaman->judul}}</a></li>
        </ol>
      </div>
    </div>
  </div>
<!--  end page banner  -->
<!-- blog right -->    
  <div id="blog-right" class="blog-page blog-left-main-block blog-right-main-block">
    <div class="container">
      <div class="row">        
        <div class="col-sm-9">
        	
          <div class="news-block">
            <div class="news-img">
              <img src="{{asset($halaman->gambar)}}" class="img-responsive" alt="{{$halaman->judul}}">      
              <div class="overlay-bg"></div>          
              
            </div>
            <div class="news-top">
              <div class="news-date text-center">
              	<?php
			        $tgl = date('d', strtotime($halaman->tgl_buat));
			        $bln = date('M', strtotime($halaman->tgl_buat));
			    ?>
                <h4 class="news-day">{{$tgl}}</h4>
                <div class="news-month">{{$bln}}</div>
              </div>
              <div class="news-heading-block">
                <h6 class="news-heading">{{$halaman->judul}}</h6>
                
              </div>
            </div>
            <div class="news-dtl">
               {!!$halaman->berita!!}
              
            </div>
             <div class="tags">
              <a href="https://www.facebook.com/sharer/sharer.php?u={{Request::url()}}"><span class="badge"><i class="fa fa-facebook"></i>  Share di FB </span></a>
                <a href="http://twitter.com/share?url={{Request::url()}}"><span class="badge"><i class="fa fa-twitter"></i>  Share di Twitter</span></a>
                <a href="https://plus.google.com/share?url={{Request::url()}}"><span class="badge"><i class="fa fa-google-plus"></i>  Share di Google+</span></a>
                <a href="whatsapp://send?text={{Request::url()}}"><span class="badge"><i class="fa fa-whatsapp"></i>  Share di WA</span></a>
   
            </div>   
          </div>
       			
          
          <hr>          
          
        </div>
        <div class="col-sm-3">
          <div class="archives-widget">
            <h6>KATEGORI</h6>
            <div class="archives-content">
              <ul>
                <li><a href="{{ url('/berita')}}"><i class="fa fa-caret-right"></i>Berita</a></li>
                <li><a href="{{ url('/informasi')}}"><i class="fa fa-caret-right"></i>Informasi</a></li>
              </ul>
            </div>
          </div>           

          <div class="tab-widget">
            <h6>Berita Terbaru</h6>
     
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active">
              	@foreach($posts as $post)
                <div class="tab-widget-dtl">
                  <div class="tab-thumb">
                    <img src="{{asset($post->gambar)}}" class="img-responsive" alt="{{$post->judul}}">
                  </div>
                  <a href="{{url('/berita/'.$post->slug)}}">{{$post->judul}}</a>
                </div>                
                @endforeach
              </div>
             </div>
            </div>
            <div class="tab-widget">
            <h6>Informasi Terbaru</h6>
     
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active">
               @foreach($infos as $info)
                <div class="tab-widget-dtl">
                  <div class="tab-thumb">
                    <img src="{{asset($info->gambar)}}" class="img-responsive" alt="{{$info->judul}}">
                  </div>
                  <a href="{{url('/informasi/'.$info->slug)}}">{{$info->judul}}</a>
                </div>                
                @endforeach
              </div>
             </div>
            </div>


          <div class="tag-widget">
            <h6>DPMPTSP Tagline</h6>
            <div class="tags">
              <a href="#"><span class="badge">dpmptsp situbondo</span></a>
              <a href="#"><span class="badge">berita situbondo</span></a>
              <a href="#"><span class="badge">informasi situbondo</span></a>
              <a href="#"><span class="badge">website dpmptsp</span></a>
               <a href="#"><span class="badge">perizinan dpmptsp</span></a>
   
            </div>       
          </div>
        </div>
      </div>
    </div>
  </div>


<!--  end latest news -->
<!--  clients -->
@include('depan.bagian.footer')
<!--  end map -->
<!--  footer -->

<!--  end footer -->
<!-- jquery -->
@include('depan.bagian.script')
<script type="text/javascript" src="https://widget.kominfo.go.id/gpr-widget-kominfo.min.js"></script>
<!-- end jquery -->
</body>
<!--body end -->
</html>


