<meta charset="utf-8" />
<meta content="width=device-width, initial-scale=1.0" name="viewport" />
<meta name="description" content="Auto Plus" />
<meta name="keywords" content="car wash, html template, car wash template, auto plus, car repair, auto wash, auto detail, auto detailing, car, cleaning, mechanic, repair, wash, car service, workshop">
<meta name="author" content="Media City" />
<meta name="MobileOptimized" content="320" />
<link rel="icon" type="image/icon" href="{{asset('tema/kominfo_dpmptsp/favicon.png')}}"> <!-- favicon-icon -->
<!-- theme style -->
<link href="{{ asset('tema/kominfo_dpmptsp/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css"/> <!-- bootstrap css -->
<link href="{{ asset('tema/kominfo_dpmptsp/css/font-awesome.min.css') }}" rel="stylesheet" type="text/css"/> <!-- fontawesome css -->
<link href="{{ asset('tema/kominfo_dpmptsp/css/icon-font.css') }}" rel="stylesheet" type="text/css"/> <!-- icon-font css -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600,700|Poppins:400,500,700" rel="stylesheet"> <!-- google font -->
<link href="{{ asset('tema/kominfo_dpmptsp/css/menumaker.css') }}" rel="stylesheet" type="text/css"/> <!-- menu css -->
<link href="{{ asset('tema/kominfo_dpmptsp/css/owl.carousel.css') }}" rel="stylesheet" type="text/css"/> <!-- owl carousel css -->
<link href="{{ asset('tema/kominfo_dpmptsp/css/magnific-popup.css') }}" rel="stylesheet" type="text/css"/> <!-- magnify popup css -->
<link href="{{ asset('tema/kominfo_dpmptsp/css/datepicker.css') }}" rel="stylesheet" type="text/css"/> <!-- datepicker css -->
<link href="{{ asset('tema/kominfo_dpmptsp/css/style.css') }}" rel="stylesheet" type="text/css"/> 

<link rel="shortcut icon" href="{{asset('tema/kominfo_dpmptsp/favicon.png')}}">
<link rel="apple-touch-icon" href="{{asset('tema/kominfo_dpmptsp/apple-touch-icon.png')}}">
<link rel="apple-touch-icon" sizes="72x72" href="{{asset('tema/kominfo_dpmptsp/apple-touch-icon-72x72.png')}}">
<link rel="apple-touch-icon" sizes="114x114" href="{{asset('tema/kominfo_dpmptsp/apple-touch-icon-114x114.png')}}">
<meta property="og:url" content="{{Request::url()}}" />
<meta property="og:type" content="website" />
<meta property="og:title" content="DPMPTSP Kabupaten Situbondo" />
<meta property="og:description" content="Website Resmi Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu Kabupaten Situbondo." />
<meta property="og:image" content="{{asset('tema/kominfo_dpmptsp/favicon.png')}}">