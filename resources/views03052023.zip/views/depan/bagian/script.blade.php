<script type="text/javascript" src="{{ asset('tema/kominfo_dpmptsp/js/jquery.min.js') }}"></script> <!-- jquery library js -->
<script type="text/javascript" src="{{ asset('tema/kominfo_dpmptsp/js/bootstrap.min.js') }}"></script> <!-- bootstrap js -->
<script type="text/javascript" src="{{ asset('tema/kominfo_dpmptsp/js/owl.carousel.js') }}"></script> <!-- owl carousel js -->
<script type="text/javascript" src="{{ asset('tema/kominfo_dpmptsp/js/jquery.ajaxchimp.js') }}"></script> <!-- mail chimp js -->
<script type="text/javascript" src="{{ asset('tema/kominfo_dpmptsp/js/smooth-scroll.js') }}"></script> <!-- smooth scroll js -->
<script type="text/javascript" src="{{ asset('tema/kominfo_dpmptsp/js/jquery.magnific-popup.min.js') }}"></script> <!-- magnify popup js --> 
<script type="text/javascript" src="{{ asset('tema/kominfo_dpmptsp/js/waypoints.min.js') }}"></script> <!-- facts count js required for jquery.counterup.js file -->
<script type="text/javascript" src="{{ asset('tema/kominfo_dpmptsp/js/jquery.counterup.js') }}"></script> <!-- facts count js-->
<script type="text/javascript" src="{{ asset('tema/kominfo_dpmptsp/js/menumaker.js') }}"></script> <!-- menu js--> 
<script type="text/javascript" src="{{ asset('tema/kominfo_dpmptsp/js/jquery.appear.js') }}"></script> <!-- progress bar js -->
<script type="text/javascript" src="{{ asset('tema/kominfo_dpmptsp/js/jquery.countdown.js') }}"></script>  <!-- event countdown js -->
<script type="text/javascript" src="{{ asset('tema/kominfo_dpmptsp/js/price-slider.js') }}"></script> <!-- price slider / filter js-->
<script type="text/javascript" src="{{ asset('tema/kominfo_dpmptsp/js/bootstrap-datepicker.js') }}"></script> <!-- bootstrap datepicker js--> 
<script type="text/javascript" src="{{ asset('tema/kominfo_dpmptsp/js/jquery.elevatezoom.js') }}"></script> <!-- image zoom js-->
<script type="text/javascript" src="{{ asset('tema/kominfo_dpmptsp/js/theme.js') }}"></script> <!-- custom js -->
<script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>  
