  <footer id="footer" class="footer-main-block">
    <div class="footer-block">
      <div class="container">
        <div class="row">

          <div class="col-md-4">
            <div class="footer-about footer-widget">
              <img src="{{ asset('tema/kominfo_dpmptsp/gambar/logo-footer-dpmptsp.png') }}" style="max-width: 320px" class="img-responsive" alt="logo">
              <div>
                    <ul>
              <li>
                <p style="color: #FFF;"><i class="fa fa-map-marker"></i>&nbsp; {{$almt->alamat}}</p>
              </li>
              <li>
                <p style="color: #FFF;"><i class="fa fa-phone"></i>&nbsp; {{$almt->telepon}}</p>
              </li>
              <li>
                <p style="color: #FFF;"><i class="fa fa-envelope"></i>&nbsp; {{$almt->email}}</p>
              </li>
                    </ul>
              </div>     
          </div>
        </div>
        <div class="clear-fix"></div>
          <div class="col-md-4">

          <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FDiskominfosit%2F&tabs=timeline&width=340&height=270&small_header=true&adapt_container_width=true&hide_cover=false&show_facepile=false&appId" width="100%" height="270" style="border:none;overflow:hidden; margin-bottom: 10px" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
          
          </div>
          <div class="clear-fix"></div>
          <div class="col-md-4">
          <a class="twitter-timeline" data-lang="id" data-height="270" data-theme="light" href="https://twitter.com/kominfo_sit">Tweets oleh Kominfo Situbondo</a>
          </div>
         <div class="clear-fix"></div>
        </div>
      </div>      
    </div>
    <hr>
    <div class="copyright">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="copyright-text text-center">
              <p style="color: #fff">&copy;  2019 DPMPTSP KABUPATEN SITUBONDO</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>