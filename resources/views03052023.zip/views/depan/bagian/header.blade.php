  <div class="top-bar hidden-xs">
    <div class="container">
      <div class="row">
        <div class="col-md-6 col-sm-6">
          <div class="info-bar">
            <ul>
              <li><i class="fa fa-phone" aria-hidden="true"></i>{{$almt->telepon}}</li>
              <li>|</li>
               <li><i class="fa fa-folder-open-o"></i><a href="http://ppid.situbondokab.go.id" style="color: #424242"> Daftar Informasi Publik </a></li>
              
            </ul>
          </div>          
        </div>
        <div class="col-md-6 col-sm-6">
          <div class="top-bar-right">
            <div class="top-menu hidden-sm">
              
            </div>
            <div class="social-icon">
              <ul>
                @foreach($sosmeds as $sosmed)
              <li><a href="{{$sosmed->link}}"><i class="fa fa-{{$sosmed->nama}}"></i></a></li>
                @endforeach
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<!--  end top bar -->
<!--  navigation -->
  <div class="nav-bar">
    <div class="container">
      <div class="row">
        <div class="col-sm-3">
          <div class="logo">
            <a href="{{url('/')}}"><img src="{{ asset('tema/kominfo_dpmptsp/gambar/logo-header-dpmptsp.png') }}" alt="logo" style="max-width: 240px"></a>
          </div>
        </div>
        <div class="col-sm-9">
          <div class="navigation">
            <div id="cssmenu">
              <ul>
                <li><a href="{{url('/')}}">Home</a>
                  
                </li>                
                 @foreach($menus as $item)
              @if($item->children->count() > 0)
              <li> <a href="#">{{$item->nama}}</a>
                <ul class="dropdown">
                @foreach($item->children as $submenu)
                  <li> <a href="{{url('/halaman/'.$submenu->alamat)}}">{{$submenu->nama}}</a> </li>
                @endforeach
                </ul>
              </li>
              @else
              <li> <a href="{{url('/halaman/'.$item->alamat)}}">{{$item->nama}}</a> </li>
              @endif
            @endforeach
            <li> <a href="#">Informasi</a>
                <ul class="dropdown">
                
                  <li> <a href="{{ url('/berita')}}"> Berita </a></li>
              <li> <a href="{{ url('/informasi')}}"> Informasi </a></li>
                
                </ul>
              </li>
             
			       <li> <a href="#">Pengaduan</a>
                <ul class="dropdown">
                
                  <li> <a href="{{url('alur-layanan-pengaduan')}}">Alur Layanan Pengaduan</a> </li>
				          <li> <a href="{{url('pejabat-penanganan-pengaduan')}}">Pejabat Penanganan Pengaduan</a> </li>
				          <li> <a href="{{url('pengaduan-dpmptsp')}}">Formulir Layanan Pengaduan</a> </li>
                
                </ul>
              </li>
              </ul>
            </div>
          </div>
        </div>        
      </div>
    </div>
  </div> 